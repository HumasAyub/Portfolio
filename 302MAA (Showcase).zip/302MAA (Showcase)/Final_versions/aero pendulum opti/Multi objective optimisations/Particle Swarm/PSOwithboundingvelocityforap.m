clear all
close all
clc

% Motor variables 

Vmin = -12%%Minimum voltage for DC motor
Vmax = 12 %%Maximum voltage for DC motor
K = 0.01
R = 5.88 % Resistance
b = 0.1 % Damping
J = 0.00214 % Inertia
Ki = 13.8*10^-3%% Torque constant (Ki should be equal to Ke) (shall be obtained from thrust test lab)
L = 0.22*10^-3% Inductance
Ke = 13.8*10^-3 % Back EMF constant
rho = 1.225 %% Density of air
Kf = 0.003 %%Disturbance torque constant(motor)
Ks = 1/100%%Saturation constant 

A1 = 0.02*0.033%% Area of first element
d1 = 0.033%% Distance of first element(for radius)
d1_t = 0.0165%% Midpoint of first element
CD1 = 0.015%% Coefficient of Drag of first element (@2 deg)
Kpd1 = 0.5*rho*A1*CD1*d1^2 %%Propellor disturbance drag of 1st element

A2 = 0.02*0.033%% Area of second element
d2 = 0.033%% Distance of second element(for radius)
d2_t = 0.0495 %% Midpoint of second element
CD2 = 0.03 %% Coefficient of second element (@5 deg)
Kpd2 = 0.5*rho*A2*CD2*d2^2 %%Propellot disturbance drag of 2nd element 

A3 = 0.02*0.033%%Area of third element
d3 = 0.033%% Distance of third element(for radius)
d3_t = 0.0825 %% Midpoint of third element 
CD3 = 0.101 %% Coefficient of drag of third element (@8 deg)
Kpd3 = 0.5*rho*A3*CD3*d3^2 %%Propellor disturbance drag of 3rd element 
r = 0.007^2 %% radius of motor shaft
k_visc = 1.81*10^-5

CL1 = 0.18 %% Coefficient of lift of first element (@2 deg)
Kpl1 = 0.5*rho*A1*CL1*d1^2 %%Lift of first element
CL2 = 0.45 %% COefficient of lift of second element (@5 deg)
Kpl2 = 0.5*rho*A1*CL2*d2^2 %% Lift of second element
CL3 = 0.4 %% Coefficient of lift of third element (@8 deg)
Kpl3 = 0.675*rho*A1*CL3*d3^2 %% Lift of third element 

%%Propellor variables
m = 0.1*9.81;
Pr = 0.1; % 4 inches = 0.1m

% Define the details of the table design problem
nVar = 3; 
ub = [4, 4, 4];
lb = [0, 0, 0];
%o = @ObjectiveFunctionPSOmobj;


% Define the PSO's paramters 
noP = 150;
maxIter = 20;
wMax = 0.9;
wMin = 0.2;
c1 = 2;
c2 = 2;
vMax = (ub - lb) .* 0.2; 
vMin  = -vMax;


% The PSO algorithm 

% Initialize the particles 
for k = 1 : noP
    Swarm.Particles(k).X = (ub-lb) .* rand(1,nVar) + lb; 
    Swarm.Particles(k).V = zeros(1, nVar); 
    Swarm.Particles(k).PBEST.X = zeros(1,nVar); 
    Swarm.Particles(k).PBEST.O = inf; 
    
    Swarm.GBEST.X = zeros(1,nVar);
    Swarm.GBEST.O = inf;

end


% Main loop
for t = 1 : maxIter
    
    % Calcualte the objective value
    for k = 1 : noP
        currentX = Swarm.Particles(k).X;
        simout = sim('optimisationofPIDMotorPSOEasy2.slx');
v = simout.Mspeed; %% Motor Speed
time = simout.tout %% time
step = simout.step %%step input as a output variable
err = step-v;
%ise = cumtrapz((err.^2), time);
S4 = trapz(err.^2)
S1 = stepinfo(v, time).SettlingTime 
S2 = stepinfo(v, time).RiseTime
S3 = stepinfo(v, time).Overshoot
AA(k) = S1
BB(k) = S2
CC(k) = S3
zzz = find(AA < S1 & BB < S2 & CC < S3)
zzz1 = numel(zzz)

o(k) = zzz1
        Swarm.Particles(k).O = o(k);
%      simout = sim('optimisationofPIDMotorPSO2.slx');
%      v = simout.Mspeed;
% time = simout.tout
% AA(k) = stepinfo(v, time).SettlingTime 
% BB(k) = stepinfo(v, time).RiseTime
%CC(k) = stepinfo(v, time).Overshoot

end 
        % Update the PBEST
        if Swarm.Particles(k).O < Swarm.Particles(k).PBEST.O 
            Swarm.Particles(k).PBEST.X = currentX;
            Swarm.Particles(k).PBEST.O = Swarm.Particles(k).O;
        end
        
        % Update the GBEST
        if Swarm.Particles(k).O < Swarm.GBEST.O;
            Swarm.GBEST.X = currentX;
            Swarm.GBEST.O = Swarm.Particles(k).O;
            %%Run code underneath to record best settling time and
            %%overshoot for each generation
            %simout2 = sim('optimisationofPIDMotorPSO2.slx');
            %vvv = simout2.Mspeed; %% Motor Speed
            %timett = simout2.tout %% time
            %GST = stepinfo(vvv, timett).SettlingTime 
            %GRT = stepinfo(vvv, timett).RiseTime
            %GO = stepinfo(vvv, timett).Overshoot
        end
    end
    
    % Update the X and V vectors 
    w = wMax - t .* ((wMax - wMin) / maxIter);
    
    for k = 1 : noP
        Swarm.Particles(k).V = w .* Swarm.Particles(k).V + c1 .* rand(1,nVar) .* (Swarm.Particles(k).PBEST.X - Swarm.Particles(k).X) ...
                                                                                     + c2 .* rand(1,nVar) .* (Swarm.GBEST.X - Swarm.Particles(k).X);
                                                                                 
        
        % Check velocities 
        index1 = find(Swarm.Particles(k).V > vMax);
        index2 = find(Swarm.Particles(k).V < vMin);
        
        Swarm.Particles(k).V(index1) = vMax(index1);
        Swarm.Particles(k).V(index2) = vMin(index2);
        
        Swarm.Particles(k).X = Swarm.Particles(k).X + Swarm.Particles(k).V;
        
        % Check positions 
        index1 = find(Swarm.Particles(k).X > ub);
        index2 = find(Swarm.Particles(k).X < lb);
        
        Swarm.Particles(k).X(index1) = ub(index1);
        Swarm.Particles(k).X(index2) = lb(index2);
        
    end
    
    outmsg = ['Iteration# ', num2str(t) , ' Swarm.GBEST.O = ' , num2str(Swarm.GBEST.O)];
    disp(outmsg);
    
cgCurve1(t) = Swarm.GBEST.O;
% cgCurve2(t) = GST;
% cgCurve3(t) = GRT;
% cgCurve4(t) = GO;

clf

 figure
plot(cgCurve1); 
xlabel('Iteration#')
ylabel('Weight')

DD(:,1) = AA
DD(:,2) = BB
DD(:,3) = CC 
[membership,member_value]=find_pareto_frontier(DD)
plot3(DD(:,1), DD(:,2), DD(:,3), '.','markersize',15);
hold on;
plot3(member_value(:,1),member_value(:,2),member_value(:,3),'.r','markersize',15);
legend({'Data','Pareto Frontier'})
hold on
xlabel('Settling Time')
ylabel('Rise Time')
zlabel('Overshoot')
grid on
%plot(cgCurve2);
%hold on 
%plot(cgCurve3);
%hold on
%plot(cgCurve4);


%% figure for plotting Generational best against each other
%%figure
%yy = [cgCurve2(2), cgCurve3(2), cgCurve4(2)]
%yy2 = [cgCurve2(1), cgCurve3(1), cgCurve4(1)]
%xx = categorical({'SettlingTime(s)','RiseTime(s)','Overshoot(%)'});
%plot(xx, yy, xx, yy2)

%% parettograph for plotting all particles of last generation 
%



% currentX = Swarm.Particles(1).X
% simout = sim('optimisationofPIDMotorPSO2.slx');
% v = simout.Mspeed;
% time = simout.tout
% D1 = stepinfo(v, time).SettlingTime 
% D2 = stepinfo(v, time).RiseTime
% D3 = stepinfo(v, time).Overshoot
% yy1 = [D1 D2 D3]
% 
% currentX = Swarm.Particles(2).X
% simout = sim('optimisationofPIDMotorPSO2.slx');
% v = simout.Mspeed; 
% time = simout.tout
% D4 = stepinfo(v, time).SettlingTime 
% D5 = stepinfo(v, time).RiseTime
% D6 = stepinfo(v, time).Overshoot
% yy2 = [D4 D5 D6]
% 
% currentX = Swarm.Particles(3).X
% simout = sim('optimisationofPIDMotorPSO2.slx');
% v = simout.Mspeed;
% time = simout.tout
% D7 = stepinfo(v, time).SettlingTime 
% D8 = stepinfo(v, time).RiseTime
% D9 = stepinfo(v, time).Overshoot
% yy3 = [D7 D8 D9]
% 
% currentX = Swarm.Particles(4).X
% simout = sim('optimisationofPIDMotorPSO2.slx');
% v = simout.Mspeed;
% time = simout.tout
% D10 = stepinfo(v, time).SettlingTime 
% D11 = stepinfo(v, time).RiseTime
% D12 = stepinfo(v, time).Overshoot
% yy4 = [D10 D11 D12]
% 
% currentX = Swarm.Particles(5).X
% simout = sim('optimisationofPIDMotorPSO2.slx');
% v = simout.Mspeed;
% time = simout.tout
% D13 = stepinfo(v, time).SettlingTime 
% D14 = stepinfo(v, time).RiseTime
% D15 = stepinfo(v, time).Overshoot
% yy5 = [D13 D14 D15]
% 
% currentX = Swarm.Particles(6).X
% simout = sim('optimisationofPIDMotorPSO2.slx');
% v = simout.Mspeed;
% time = simout.tout
% D16 = stepinfo(v, time).SettlingTime 
% D17 = stepinfo(v, time).RiseTime
% D18 = stepinfo(v, time).Overshoot
% yy6 = [D16 D17 D18]
% 
% currentX = Swarm.Particles(7).X
% simout = sim('optimisationofPIDMotorPSO2.slx');
% v = simout.Mspeed;
% time = simout.tout
% D19 = stepinfo(v, time).SettlingTime 
% D20 = stepinfo(v, time).RiseTime
% D21 = stepinfo(v, time).Overshoot
% yy7 = [D19 D20 D21]
% 
% currentX = Swarm.Particles(8).X
% simout = sim('optimisationofPIDMotorPSO2.slx');
% v = simout.Mspeed;
% time = simout.tout
% D22 = stepinfo(v, time).SettlingTime 
% D23 = stepinfo(v, time).RiseTime
% D24 = stepinfo(v, time).Overshoot
% yy8 = [D22 D23 D24]
% 
% currentX = Swarm.Particles(9).X
% simout = sim('optimisationofPIDMotorPSO2.slx');
% v = simout.Mspeed;
% time = simout.tout
% D25 = stepinfo(v, time).SettlingTime 
% D26 = stepinfo(v, time).RiseTime
% D27 = stepinfo(v, time).Overshoot
% yy9 = [D25 D26 D27]
% 
% currentX = Swarm.Particles(10).X
% simout = sim('optimisationofPIDMotorPSO2.slx');
% v = simout.Mspeed;
% time = simout.tout
% D28 = stepinfo(v, time).SettlingTime 
% D29 = stepinfo(v, time).RiseTime
% D30 = stepinfo(v, time).Overshoot
% yy10 = [D28 D29 D30]
% 
% currentX = Swarm.Particles(11).X
% simout = sim('optimisationofPIDMotorPSO2.slx');
% v = simout.Mspeed;
% time = simout.tout
% D31 = stepinfo(v, time).SettlingTime 
% D32 = stepinfo(v, time).RiseTime
% D33 = stepinfo(v, time).Overshoot
% yy11 = [D31 D32 D33]
% 
% currentX = Swarm.Particles(12).X
% simout = sim('optimisationofPIDMotorPSO2.slx');
% v = simout.Mspeed;
% time = simout.tout
% D34 = stepinfo(v, time).SettlingTime 
% D35 = stepinfo(v, time).RiseTime
% D36 = stepinfo(v, time).Overshoot
% yy12 = [D34 D35 D36]
% 
% currentX = Swarm.Particles(13).X
% simout = sim('optimisationofPIDMotorPSO2.slx');
% v = simout.Mspeed;
% time = simout.tout
% D37 = stepinfo(v, time).SettlingTime 
% D38 = stepinfo(v, time).RiseTime
% D39 = stepinfo(v, time).Overshoot
% yy13 = [D37 D38 D39]
% 
% currentX = Swarm.Particles(14).X
% simout = sim('optimisationofPIDMotorPSO2.slx');
% v = simout.Mspeed;
% time = simout.tout
% D40 = stepinfo(v, time).SettlingTime 
% D41 = stepinfo(v, time).RiseTime
% D42 = stepinfo(v, time).Overshoot
% yy14 = [D40 D41 D42]
% 
% currentX = Swarm.Particles(15).X
% simout = sim('optimisationofPIDMotorPSO2.slx');
% v = simout.Mspeed;
% time = simout.tout
% D43 = stepinfo(v, time).SettlingTime 
% D44 = stepinfo(v, time).RiseTime
% D45 = stepinfo(v, time).Overshoot
% yy15 = [D43 D44 D45]
% 
% currentX = Swarm.Particles(16).X
% simout = sim('optimisationofPIDMotorPSO2.slx');
% v = simout.Mspeed;
% time = simout.tout
% D46 = stepinfo(v, time).SettlingTime 
% D47 = stepinfo(v, time).RiseTime
% D48 = stepinfo(v, time).Overshoot
% yy16 = [D46 D47 D48]
% 
% currentX = Swarm.Particles(17).X
% simout = sim('optimisationofPIDMotorPSO2.slx');
% v = simout.Mspeed;
% time = simout.tout
% D49 = stepinfo(v, time).SettlingTime 
% D50 = stepinfo(v, time).RiseTime
% D51 = stepinfo(v, time).Overshoot
% yy17 = [D49 D50 D51]
% 
% currentX = Swarm.Particles(18).X
% simout = sim('optimisationofPIDMotorPSO2.slx');
% v = simout.Mspeed;
% time = simout.tout
% D52 = stepinfo(v, time).SettlingTime 
% D53 = stepinfo(v, time).RiseTime
% D54 = stepinfo(v, time).Overshoot
% yy18 = [D52 D53 D54]
% 
% currentX = Swarm.Particles(19).X
% simout = sim('optimisationofPIDMotorPSO2.slx');
% v = simout.Mspeed;
% time = simout.tout
% D55 = stepinfo(v, time).SettlingTime 
% D56 = stepinfo(v, time).RiseTime
% D57 = stepinfo(v, time).Overshoot
% yy19 = [D55 D56 D57]
% 
% currentX = Swarm.Particles(20).X
% simout = sim('optimisationofPIDMotorPSO2.slx');
% v = simout.Mspeed;
% time = simout.tout
% D58 = stepinfo(v, time).SettlingTime 
% D59 = stepinfo(v, time).RiseTime
% D60 = stepinfo(v, time).Overshoot
% yy20 = [D58 D59 D60]
% 
% yy21 = [D1 D4 D7 D10 D13 D16 D19 D22 D25 D28 D31 D34 D37 D40 D43 D46 D49 D52 D55 D58]
% yy22 = [D2 D5 D8 D11 D14 D17 D20 D23 D26 D29 D32 D35 D38 D41 D44 D47 D50 D53 D56 D59]
% yy23 = [D3 D6 D9 D12 D15 D18 D21 D24 D27 D30 D33 D36 D39 D42 D45 D48 D51 D54 D57 D60]

%%Generating parreto front
[membership,member_value]=find_pareto_frontier([yy21; yy22; yy23])
plot3(yy21, yy22, yy23, '.','markersize',15);
hold on;
plot3(member_value(:,1),member_value(:,2),member_value(:,3),'.r','markersize',15);
legend({'Data','Pareto Frontier'})
hold on
xlabel('Settling Time')
ylabel('Rise Time')
zlabel('Overshoot')
grid on
%yyST = [0 1]  %Desired settling time
%yyRT = [1 1]  %Desired Rise Time
%yyO =  [1 1]  %Desired overshoot
%yy24 = [D1 D4 D7 D10 D13 D16 D19 D22 D25 D28 D31 D34 D37 D40 D43 D46 D49 D52 D55 D58; D2 D5 D8 D11 D14 D17 D20 D23 D26 D29 D32 D35 D38 D41 D44 D47 D50 D53 D56 D59; D3 D6 D9 D12 D15 D18 D21 D24 D27 D30 D33 D36 D39 D42 D45 D48 D51 D54 D57 D60]
%xx = categorical({'SettlingTime(s)','RiseTime(s)','Overshoot(%)'});figure
%plot(xx, yy1, xx, yy2, xx, yy3, xx, yy4, xx, yy5, xx, yy6, xx, yy7, xx, yy8, xx, yy9, xx, yy10, xx, yy11, xx, yy12, xx, yy13, xx, yy14, xx, yy15, xx, yy16, xx, yy16, xx, yy17, xx, yy18, xx, yy19, xx, yy20)
%plot3(yy21, yy22, yy23, 'o')
%plot3(yyST, yyRT, yyO, '-')


Swarm.ParticlesCharacteristics = [yy1 1;yy2 2;yy3 3;yy4 4;yy5 5;yy6 6;yy7 7;yy8 8;yy9 9;yy10 10;yy11 11;yy12 12;yy13 13;yy14 14;yy15 15;yy16 16;yy17 17;yy18 18;yy19 19;yy20 20]

%%First column is settling time
%%Second column is Rise Time
%%THird column is overshoot
%%fourth column is particle number

%% bar chart plot of system characteristics of best solution 
currentX(1) = Swarm.GBEST.X(1)
currentX(2) = Swarm.GBEST.X(2)
currentX(3) = Swarm.GBEST.X(3)
simout = sim('optimisationofPIDMotorPSO2.slx');
Re = simout.Reynolds_no
step = simout.step
v = simout.Mspeed;
time = simout.tout
err = step-v;
S4 = trapz(err.^2)
S1 = stepinfo(v, time).SettlingTime 
S2 = stepinfo(v, time).RiseTime
S3 = stepinfo(v, time).Overshoot

figure
a = [S1 S2 S3 S4]
X = categorical({'SettlingTime(s)','RiseTime(s)','Overshoot(%)', 'Error'});
X = reordercats(X,{'SettlingTime(s)','RiseTime(s)','Overshoot(%)', 'Error'});
bar(X, a) 
title('System characteristics with optimised PID values')
legend