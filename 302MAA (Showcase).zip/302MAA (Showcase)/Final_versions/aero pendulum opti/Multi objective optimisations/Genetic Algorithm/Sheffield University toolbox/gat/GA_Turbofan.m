%GA tuning of turbofan engine
%09/02/2004

close all
MN=0.0;
Alt=0;
Altm=Alt*12*25.4/1000;
ISAAlt=[0:500:15000];
ISAP0=[1.01325,0.9546,0.8988,0.8456,0.795,0.7469,0.7012,0.6578,0.6166,0.5775,0.5405,0.5054,0.4722,0.4408,0.4111,0.383,0.3565,0.3315,0.308,0.2858,0.2650,0.2454,0.227,0.2098,0.194,0.1793,0.1658,0.1533,0.1417,0.131,0.1211];
ISADen=[1,0.9529,0.9075,0.8638,0.8217,0.7812,0.7423,0.7048,0.6689,0.6343,0.6012,0.5694,0.5389,0.5096,0.4817,0.4549,0.4292,0.4047,0.3813,0.3589,0.3376,0.3172,0.2978,0.2755,0.2546,0.2354,0.2176,0.2012,0.186,0.172,0.159];
ISASLDen=1.225;
P0=interp1(ISAAlt,ISAP0,Altm);
P0=P0*10^5;
if Altm > 11000
   T0=216.7;
else
   T0=288.15-(6.5*Altm/1000);
end

BleedF=0.015;
DeltaPComb=0.01;
EtaInt=0.94;
EtaFan=0.92;
EtaComp=0.89;
EtaLPTurb=0.95;
EtaHPTurb=0.95;
EtaNozHot=0.96;
EtaNozCold=0.96;
GammaAir=1.4;
CPAir=1005;
RAir=287;
GammaBurnt=1.333;
CPBurnt=1148;
RBurnt=287;
CFuel=43*10^6;
ElectPower=1.0*10^6;
ElecGenEff=0.95;
ElecStartEff=1.0;
PumpEnergy=100*10^3;
LPShaftPowerTransfer=0.0;

SpecificThrustDem = 325
mdot=180*10^3/SpecificThrustDem


NIND = 2000;          % Number of individuals per subpopulations
MAXGEN = 59;        % maximum Number of generations
GGAP = .94;          % Generation gap, how many new individuals are created
NVAR = 4;            % Generation gap, how many new individuals are created
PRECI = 24;          % Precision of binary representation
% Build field descriptor
   FieldD = [rep([PRECI],[1, NVAR]); rep([-5;2],[1, NVAR]);...
              rep([1; 0; 1 ;1], [1, NVAR])];
FieldD(2,1)=5;		%cpr
FieldD(3,1)=45;
FieldD(2,2)=1;		%bpr
FieldD(3,2)=8;
FieldD(2,3)=1;		%fpr
FieldD(3,3)=2;
FieldD(2,4)=700;	%t04
FieldD(3,4)=1600;

% Initialise population
   Chrom = crtbp(NIND, NVAR*PRECI);
% Reset counters
   Best = NaN*ones(MAXGEN,1);	% best in current population
   gen = 0;			% generational counter
% Evaluate initial population
ECycle = bs2rv(Chrom,FieldD);
ObjV=zeros([NIND,1]);
for icount=1:NIND
	CPR=ECycle(icount,1);
	BPR=ECycle(icount,2);
	FPR=ECycle(icount,3);
   T04=ECycle(icount,4);
   MDotCold=(mdot*BPR)/(BPR+1);
   MDotHot=mdot/(BPR+1);
%   [F,f,SFC,Eta,MDotFuel,FAR,ANozCold,ANozHot]=turbofan(MN,T0,P0,FPR,BPR,CPR,BleedF,DeltaPComb,T04,EtaInt,EtaFan,EtaComp,EtaTurb,EtaNozHot,EtaNozCold,MDotHot,MDotCold,GammaAir,CPAir,RAir,GammaBurnt,CPBurnt,RBurnt,CFuel,ElectPower,ElectEff,PumpEnergy);
   [F,f,SFC,Eta,MDotFuel,FAR,ANozCold,ANozHot]=turbofan(MN,T0,P0,FPR,BPR,CPR,BleedF,DeltaPComb,T04,EtaInt,EtaFan,EtaComp,EtaLPTurb,EtaHPTurb,EtaNozHot,EtaNozCold,MDotHot,MDotCold,GammaAir,CPAir,RAir,GammaBurnt,CPBurnt,RBurnt,CFuel,ElectPower,ElecGenEff,PumpEnergy,LPShaftPowerTransfer,ElecStartEff);

   if SFC == NaN
      SFC = 1000;
   elseif f < SpecificThrustDem
      SFC = 100;
   end
	ObjV(icount)=SFC*3600;
end

% Track best individual and display convergence
   Best(gen+1) = min(ObjV);

% Generational loop
   while gen < MAXGEN,
    % Assign fitness-value to entire population
       FitnV = ranking(ObjV);
    % Select individuals for breeding
       SelCh = select('sus', Chrom, FitnV, GGAP);
    % Recombine selected individuals (crossover)
       SelCh = recombin('xovsp',SelCh,0.7);
    % Perform mutation on offspring
       SelCh = mut(SelCh);
    % Evaluate offspring, call objective function
		ECycle = bs2rv(SelCh,FieldD);
		ObjVSel=zeros([NIND*GGAP,1]);
		for icount=1:NIND*GGAP
			CPR=ECycle(icount,1);
			BPR=ECycle(icount,2);
			FPR=ECycle(icount,3);
         T04=ECycle(icount,4);
         MDotCold=(mdot*BPR)/(BPR+1);
         MDotHot=mdot/(BPR+1);
      %   [F,f,SFC,Eta,MDotFuel,FAR,ANozCold,ANozHot]=turbofan(MN,T0,P0,FPR,BPR,CPR,BleedF,DeltaPComb,T04,EtaInt,EtaFan,EtaComp,EtaTurb,EtaNozHot,EtaNozCold,MDotHot,MDotCold,GammaAir,CPAir,RAir,GammaBurnt,CPBurnt,RBurnt,CFuel,ElectPower,ElectEff,PumpEnergy);
         [F,f,SFC,Eta,MDotFuel,FAR,ANozCold,ANozHot]=turbofan(MN,T0,P0,FPR,BPR,CPR,BleedF,DeltaPComb,T04,EtaInt,EtaFan,EtaComp,EtaLPTurb,EtaHPTurb,EtaNozHot,EtaNozCold,MDotHot,MDotCold,GammaAir,CPAir,RAir,GammaBurnt,CPBurnt,RBurnt,CFuel,ElectPower,ElecGenEff,PumpEnergy,LPShaftPowerTransfer,ElecStartEff); 
         if SFC == NaN
	         SFC = 1000;
	      elseif f < SpecificThrustDem
	         SFC = 100;   
	      end
			ObjVSel(icount)=SFC*3600;
		end

    % Reinsert offspring into current population
       [Chrom ObjV]=reins(Chrom,SelCh,1,1,ObjV,ObjVSel);
    % Increment generational counter
       gen = gen+1;
    % Update display and record current best individual
       Best(gen+1) = min(ObjV);
%       plot(log10(Best),'ro'); xlabel('generation'); ylabel('log10(f(x))');
       plot(Best,'ro'); xlabel('generation'); ylabel('f(x)');
       text(0.5,0.95,['Best = ', num2str(Best(gen+1))],'Units','normalized');       
       [minobjv,minobjvi]=min(ObjV);
		 ECycle = bs2rv(Chrom,FieldD);
       CPRbest=ECycle(minobjvi,1);
       BPRbest=ECycle(minobjvi,2);
       FPRbest=ECycle(minobjvi,3); 
       T04best=ECycle(minobjvi,4);
       text(0.5,0.9,['CPR = ', num2str(CPRbest)],'Units','normalized');
       text(0.5,0.85,['BPR = ', num2str(BPRbest)],'Units','normalized');
       text(0.5,0.8,['FPR = ', num2str(FPRbest)],'Units','normalized');
       text(0.5,0.75,['T04 = ', num2str(T04best)],'Units','normalized');
       drawnow;
   end 
% End of GA


% Performance of best engine cycle at TO
[minobjv,minobjvi]=min(ObjV);
ECycle = bs2rv(Chrom,FieldD);
CPRbest=ECycle(minobjvi,1);
BPRbest=ECycle(minobjvi,2);
FPRbest=ECycle(minobjvi,3);
T04best=ECycle(minobjvi,4);
MDotColdbest=(mdot*BPRbest)/(BPRbest+1);
MDotHotbest=mdot/(BPRbest+1);
%[Fbest,fbest,SFCbest,Etabest,MDotFuelbest,FARbest,ANozColdbest,ANozHotbest]=turbofan(MN,T0,P0,FPRbest,BPRbest,CPRbest,BleedF,DeltaPComb,T04best,EtaInt,EtaFan,EtaComp,EtaTurb,EtaNozHot,EtaNozCold,MDotHotbest,MDotColdbest,GammaAir,CPAir,RAir,GammaBurnt,CPBurnt,RBurnt,CFuel,ElectPower,ElectEff,PumpEnergy);
[Fbest,fbest,SFCbest,Etabest,MDotFuelbest,FARbest,ANozColdbest,ANozHotbest]=turbofan(MN,T0,P0,FPRbest,BPRbest,CPRbest,BleedF,DeltaPComb,T04best,EtaInt,EtaFan,EtaComp,EtaLPTurb,EtaHPTurb,EtaNozHot,EtaNozCold,MDotHot,MDotCold,GammaAir,CPAir,RAir,GammaBurnt,CPBurnt,RBurnt,CFuel,ElectPower,ElecGenEff,PumpEnergy,LPShaftPowerTransfer,ElecStartEff); 


% Performance of best engine cycle at cruise
%MN=0.75;
%Alt=33000;
%Altm=Alt*12*25.4/1000;
%ISAAlt=[0:500:15000];
%ISAP0=[1.01325,0.9546,0.8988,0.8456,0.795,0.7469,0.7012,0.6578,0.6166,0.5775,0.5405,0.5054,0.4722,0.4408,0.4111,0.383,0.3565,0.3315,0.308,0.2858,0.2650,0.2454,0.227,0.2098,0.194,0.1793,0.1658,0.1533,0.1417,0.131,0.1211];
%ISADen=[1,0.9529,0.9075,0.8638,0.8217,0.7812,0.7423,0.7048,0.6689,0.6343,0.6012,0.5694,0.5389,0.5096,0.4817,0.4549,0.4292,0.4047,0.3813,0.3589,0.3376,0.3172,0.2978,0.2755,0.2546,0.2354,0.2176,0.2012,0.186,0.172,0.159];
%ISASLDen=1.225;
%P0=interp1(ISAAlt,ISAP0,Altm);
%P0=P0*10^5;
%if Altm > 11000
%   T0=216.7;
%else
%   T0=288.15-(6.5*Altm/1000);
%end
%InletDiameter=2;
%AirDensity=interp1(ISAAlt,ISADen,Altm);
%InletMassFlowRate=MN*sqrt(GammaAir*RAir*T0)*(pi*InletDiameter*InletDiameter/4)*AirDensity;
%mdot=InletMassFlowRate;
%MDotColdbest=(mdot*BPRbest)/(BPRbest+1);

%MDotHotbest=mdot/(BPRbest+1);
%[Fbestc,fbestc,SFCbestc,Etabestc,MDotFuelbestc,FARbestc,ANozColdbestc,ANozHotbestc]=turbofan(MN,T0,P0,FPRbest,BPRbest,CPRbest,BleedF,DeltaPComb,T04best,EtaInt,EtaFan,EtaComp,EtaTurb,EtaNozHot,EtaNozCold,MDotHotbest,MDotColdbest,GammaAir,CPAir,RAir,GammaBurnt,CPBurnt,RBurnt,CFuel,ElectPower,ElectEff,PumpEnergy);
%ThrustDem=55*10^3;
%for i=1,10
%   mdot=mdot*ThrustDem/Fbestc
%	[Fbestc,fbestc,SFCbestc,Etabestc,MDotFuelbestc,FARbestc,ANozColdbestc,ANozHotbestc]=turbofan(MN,T0,P0,FPRbest,BPRbest,CPRbest,BleedF,DeltaPComb,T04best,EtaInt,EtaFan,EtaComp,EtaTurb,EtaNozHot,EtaNozCold,MDotHotbest,MDotColdbest,GammaAir,CPAir,RAir,GammaBurnt,CPBurnt,RBurnt,CFuel,ElectPower,ElectEff,PumpEnergy);
%end

