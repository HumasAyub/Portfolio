clear all
close all
clc

% Motor variables 

Vmin = -12%%Minimum voltage for DC motor
Vmax = 12 %%Maximum voltage for DC motor
K = 0.01
R = 5.88 % Resistance
b = 0.1 % Damping
J = 0.00214 % Inertia
Ki = 13.8*10^-3%% Torque constant (Ki should be equal to Ke) (shall be obtained from thrust test lab)
L = 0.22*10^-3% Inductance
Ke = 13.8*10^-3 % Back EMF constant
rho = 1.225 %% Density of air
Kf = 0.003 %%Disturbance torque constant(motor)
Ks = 1/100%%Saturation constant 

A1 = 0.02*0.033%% Area of first element
d1 = 0.033%% Distance of first element(for radius)
d1_t = 0.0165%% Midpoint of first element
CD1 = 0.015%% Coefficient of Drag of first element (@2 deg)
Kpd1 = 0.5*rho*A1*CD1*d1^2 %%Propellor disturbance drag of 1st element

A2 = 0.02*0.033%% Area of second element
d2 = 0.033%% Distance of second element(for radius)
d2_t = 0.0495 %% Midpoint of second element
CD2 = 0.03 %% Coefficient of second element (@5 deg)
Kpd2 = 0.5*rho*A2*CD2*d2^2 %%Propellot disturbance drag of 2nd element 

A3 = 0.02*0.033%%Area of third element
d3 = 0.033%% Distance of third element(for radius)
d3_t = 0.0825 %% Midpoint of third element 
CD3 = 0.101 %% Coefficient of drag of third element (@8 deg)
Kpd3 = 0.5*rho*A3*CD3*d3^2 %%Propellor disturbance drag of 3rd element 
r = 0.007^2 %% radius of motor shaft
k_visc = 1.81*10^-5

CL1 = 0.18 %% Coefficient of lift of first element (@2 deg)
Kpl1 = 0.5*rho*A1*CL1*d1^2 %%Lift of first element
CL2 = 0.45 %% COefficient of lift of second element (@5 deg)
Kpl2 = 0.5*rho*A1*CL2*d2^2 %% Lift of second element
CL3 = 0.4 %% Coefficient of lift of third element (@8 deg)
Kpl3 = 0.675*rho*A1*CL3*d3^2 %% Lift of third element 

%%Propellor variables
m = 0.1*9.81;
Pr = 0.1; % 4 inches = 0.1m

% sga.m
%
% This script implements the Simple Genetic Algorithm described
% in the examples section of the GA Toolbox manual.
%
% Author:     Andrew Chipperfield
% History:    23-Mar-94     file created
%
% tested under MATLAB v6 by Alex Shenfield (22-Jan-03)

NIND = 300;           % Number of individuals per subpopulations
MAXGEN = 40;        % maximum Number of generations
GGAP = .5;           % Generation gap, how many new individuals are created
NVAR = 3;           % Number of variables
PRECI = 24;          % Precision of binary representation

% Build field descriptor
   FieldD = [rep([PRECI],[1, NVAR]); rep([-5;2],[1, NVAR]);...
              rep([1; 0; 1 ;1], [1, NVAR])];

 FieldD(2,1)=0;		%Kp
FieldD(3,1)=4;
FieldD(2,2)=0;		%Ki
FieldD(3,2)=4;
FieldD(2,3)=0;		%Kd
FieldD(3,3)=4;

% Initialise population
   Chrom = crtbp(NIND, NVAR*PRECI);

% Reset counters
   Best = NaN*ones(MAXGEN,1);	% best in current population
   gen = 0;			% generational counter

% Evaluate initial population

aaa = bs2rv(Chrom,FieldD);
ObjV=zeros([NIND,1]);
%AA = zeros([NIND,1]);
%BB = zeros([NIND,1]);
for icount=1:NIND
	k(1)=aaa(icount,1); %Kp value the optimisation has chosen
	k(2)=aaa(icount,2); %Ki value the optimisation has chosen
	k(3)=aaa(icount,3); %Kd value the optimisation has chosen
simout = sim('optimisationofPIDMotorGANMEasy2.slx');
v = simout.Mspeed; %% Motor Speed
time = simout.tout %% time
step = simout.step %%step input as a output variable
S1 = stepinfo(v, time).SettlingTime %Find Settling Time
S2 = stepinfo(v, time).RiseTime %Find Rise Time
S3 = stepinfo(v, time).Overshoot %Find OVershoot

AA(icount) = S1 %All other Settling Times obtained
BB(icount) = S2 %All other Rise Times obtained
DD(icount) = S3 %All other Overshoots obtained
zzz = find(AA < S1 & BB < S2 & DD < S3) %Find solutions that dominate the current solution
zzz1 = numel(zzz) %Number of solution that dominate current solution
    ObjV(icount) = zzz1 %Make it the objective value
end



%%newaaa = aaa(icount)

% Track best individual and display convergence
 Best(gen+1) = min(ObjV);
 %plot(log10(Best),'ro');xlabel('generation'); ylabel('log10(f(x))');
 %text(0.5,0.95,['Best = ', num2str(Best(gen+1))],'Units','normalized');   
   %drawnow;        

% Generational loop
   while gen < MAXGEN,
    % Assign fitness-value to entire population
       FitnV = ranking(ObjV);
    % Select individuals for breeding
       SelCh = select('sus', Chrom, FitnV, GGAP);
    % Recombine selected individuals (crossover)
       SelCh = recombin('xovsp',SelCh,0.7);
    % Perform mutation on offspring
       SelCh = mut(SelCh);
    % Evaluate offspring, call objective function
       %ObjVSel = objfun1(bs2rv(SelCh,FieldD));
       		aaa = bs2rv(SelCh,FieldD);
		ObjVSel=zeros([NIND*GGAP,1]);
for icount=1:NIND*GGAP
	k(1) = aaa(icount,1);
	k(2) = aaa(icount,2);
	k(3) = aaa(icount,3);
    simout = sim('optimisationofPIDMotorGANMEasy2.slx');
v = simout.Mspeed; %% Motor Speed
time = simout.tout %% time
step = simout.step %%step input as a output variable
err = step-v;
%ise = cumtrapz((err.^2), time);
S4 = trapz(err.^2)
S1 = stepinfo(v, time).SettlingTime 
S2 = stepinfo(v, time).RiseTime
S3 = stepinfo(v, time).Overshoot
%[membership,member_value]=find_pareto_frontier([S1; S2])
AA(icount) = S1
BB(icount) = S2
DD(icount) = S3


%create an area made by coords of S1 and S2
%identify points in that area 

zzz = find(AA < S1 & BB < S2 & DD < S3)
%zzz = find(AA < S1 & BB < S2)
zzz1 = numel(zzz)

ObjVSel(icount) = zzz1

end

    % Reinsert offspring into current population
       [Chrom ObjV]=reins(Chrom,SelCh,1,1,ObjV,ObjVSel);

    % Increment generational counter
       gen = gen+1;

 % Update display and record current best individual
       Best(gen+1) = min(ObjV);
%       plot(log10(Best),'ro'); xlabel('generation'); ylabel('log10(f(x))');
       plot(Best,'ro'); xlabel('generation'); ylabel('f(x)');
       text(0.5,0.95,['Best = ', num2str(Best(gen+1))],'Units','normalized');       
       [minobjv,minobjvi]=min(ObjV);
		 aaa = bs2rv(Chrom,FieldD);
       Kpbest = aaa(minobjvi,1);
       Kibest = aaa(minobjvi,2);
       Kdbest = aaa(minobjvi,3); 
       text(0.5,0.9,['Kp = ', num2str(Kpbest)],'Units','normalized');
       text(0.5,0.85,['Ki = ', num2str(Kibest)],'Units','normalized');
       text(0.5,0.8,['Kd = ', num2str(Kdbest)],'Units','normalized');
       drawnow;
   end 
% End of GA


    % Update display and record current best individual
       %Best(gen+1) = min(ObjV);
       %plot(log10(Best),'ro'); xlabel('generation'); ylabel('log10(f(x))');
       %text(0.5,0.95,['Best = ', num2str(Best(gen+1))],'Units','normalized');
       %drawnow;
      
% End of GA


CC(:,1) = AA %All settling times
CC(:,2) = BB %All rise time
CC(:,3) = DD %All overshoots 
[membership,member_value]=find_pareto_frontier(CC)
plot3(CC(:,1), CC(:,2), CC(:,3), '.')
%plot(CC(:,1), CC(:,2), 'o')
hold on 
plot3(member_value(:,1),member_value(:,2), member_value(:,3),'.r');
%plot(member_value(:,1),member_value(:,2), 'r')
grid on
legend({'Data','Pareto Frontier'})
xlabel('Settling Time(s)')
ylabel('Rise Time(s)')
zlabel('Overshoot')