function o  = ObjectiveFunction3 ( k )
%assignin('base','k',k);
simout = sim('optimisationofPIDMotorNM.slx');
v = simout.Mspeed; %% Motor Speed
time = simout.tout %% time
step = simout.step %%step input as a output variable
err = step-v;
%ise = cumtrapz((err.^2), time);
S4 = trapz(err.^2)
S1 = stepinfo(v, time).SettlingTime 
S2 = stepinfo(v, time).RiseTime
S3 = stepinfo(v, time).Overshoot

o(1) = S1 
o(2) = S2  
o(3) = S3