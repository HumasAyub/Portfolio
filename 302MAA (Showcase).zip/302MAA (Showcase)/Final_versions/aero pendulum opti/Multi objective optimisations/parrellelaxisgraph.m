load history.mat
for k=1:MaxIter
        sortedcost(:,k) = sort(cost(:,k));
end
imagesc(log(sortedcost(:,1:MaxIter)))
colorbar
set(gcf,'Position',[100 100 600 300])
set(gcf,'PaperPositionMode','auto')
print('-deps2', '-loose', '../../figures/GAPID1');