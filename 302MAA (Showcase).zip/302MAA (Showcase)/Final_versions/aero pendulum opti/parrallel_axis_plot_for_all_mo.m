%%Gahardoptimisation 
QC(:,1) = [2.2357,  2.5664 , 2.6303 , 2.7531,  2.7591, 5.4152] %% Settling times
QC(:,2) = [0.8614, 0.9716, 0.9536, 0.7714 , 0.7561  , 0.5596] %% Rise times 
QC(:,3) = [1.9820, 0.2636, 0.0250, 0.0002, 0, 0] %% Overshoot 

a = [QC(:,1), QC(:,2), QC(:,3), QC(:,1)]
X = categorical({'SettlingTime(s)','RiseTime(s)','Overshoot(%)', 'SettlingTime2(s)'});
X = reordercats(X,{'SettlingTime(s)','RiseTime(s)','Overshoot(%)', 'SettlingTime2(s)'});
figure
plot(X, a)
title('Multi-objective opti of an aero pendulum of high complexity using GA')

% drawnow
%GA intermediateoptimisation
QC(:,1) = [2.4087 ,  2.5908 , 2.7459  ,  3.1502,  3.4090, 3.5817] %% Settling times
QC(:,2) = [0.9654, 0.9433, 0.8481, 0.9297,1.0383, 0.8014] %% Rise times 
QC(:,3) = [1.8260, 0.1580, 0.0047, 0.0008, 0, 5.8080] %% Overshoot 

a = [QC(:,1), QC(:,2), QC(:,3), QC(:,1)]
X = categorical({'SettlingTime(s)','RiseTime(s)','Overshoot(%)', 'SettlingTime2(s)'});
X = reordercats(X,{'SettlingTime(s)','RiseTime(s)','Overshoot(%)', 'SettlingTime2(s)'});
plot(X, a)
title('Multi-objective opti of an aero pendulum of medium complexity using GA')


%Ga easyoptimisation 
QC(:,1) = [2.2959 ,  2.3615 , 2.5080  ,   2.9782,  3.9736 , 8.9796] %% Settling times
QC(:,2) = [0.8774 , 0.9120 , 0.9198, 1.0382 , 0.8910 ,  0.5295] %% Rise times 
QC(:,3) = [1.6551, 1.2896, 0.2418, 0, 0, 0] %% Overshoot 

a = [QC(:,1), QC(:,2), QC(:,3), QC(:,1)]
X = categorical({'SettlingTime(s)','RiseTime(s)','Overshoot(%)', 'SettlingTime2(s)'});
X = reordercats(X,{'SettlingTime(s)','RiseTime(s)','Overshoot(%)', 'SettlingTime2(s)'});
plot(X, a)
title('Multi-objective opti of an aero pendulum of low complexity using GA')


%%PSO hard optimisation 
QC(:,1) = [2.4590, 3.0064 ,3.0092, 3.8545, 4.2069] %% Settling times
QC(:,2) = [0.7618,1.0379,1.1386, 0.9428,1.0237] %% Rise times 
QC(:,3) = [0.0105,0.0012,0 0.0041,0.0004] %% Overshoot 

a = [QC(:,1), QC(:,2), QC(:,3), QC(:,1)]
X = categorical({'SettlingTime(s)','RiseTime(s)','Overshoot(%)', 'SettlingTime2(s)'});
X = reordercats(X,{'SettlingTime(s)','RiseTime(s)','Overshoot(%)', 'SettlingTime2(s)'});
plot(X, a)
title('Multi-objective opti of an aero pendulum of high complexity using PSO')


%PSO intermediateoptimisaiton
QC(:,1) = [2.3358 ,   2.4601  ,  2.9107] %% Settling times
QC(:,2) = [0.9376   , 0.9091, 0.7366] %% Rise times 
QC(:,3) = [1.8895,  0.5201, 0] %% Overshoot 

a = [QC(:,1), QC(:,2), QC(:,3), QC(:,1)]
X = categorical({'SettlingTime(s)','RiseTime(s)','Overshoot(%)', 'SettlingTime2(s)'});
X = reordercats(X,{'SettlingTime(s)','RiseTime(s)','Overshoot(%)', 'SettlingTime2(s)'});
plot(X, a)
title('Multi-objective opti of an aero pendulum of medium complexity using PSO')


%PSO easy optimisation
QC(:,1) = [2.3390,   2.4311] %% Settling times
QC(:,2) = [0.8114, 0.7905] %% Rise times 
QC(:,3) = [0.3187, 0] %% Overshoot 

a = [QC(:,1), QC(:,2), QC(:,3), QC(:,1)]
X = categorical({'SettlingTime(s)','RiseTime(s)','Overshoot(%)', 'SettlingTime2(s)'});
X = reordercats(X,{'SettlingTime(s)','RiseTime(s)','Overshoot(%)', 'SettlingTime2(s)'});
plot(X, a)
title('Multi-objective opti of an aero pendulum of low complexity using PSO')

