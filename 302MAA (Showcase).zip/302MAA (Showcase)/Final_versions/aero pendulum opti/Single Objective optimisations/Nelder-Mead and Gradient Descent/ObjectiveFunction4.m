function  o  = ObjectiveFunction4 (data)

% Step = data.Step
% Responce = data.MotorResponce
% err = Step - Responce
% e = trapz(err^2)
currentX = data.DesignVars
%currentX(2) = data.DesignVars(2)
%currentX(3) = data.DesignVars(3)
simout = sim("optimisationofPIDMotorExtra.slx")
v = simout.Mspeed; %% Motor Speed
time = simout.tout %% time
step = simout.step %%step input as a output variable
err = step-v;
%ise = cumtrapz((err.^2), time);
S4 = trapz(err.^2)


o = S4

end