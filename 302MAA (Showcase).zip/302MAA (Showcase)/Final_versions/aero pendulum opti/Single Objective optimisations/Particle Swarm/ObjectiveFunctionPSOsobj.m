function [ o ] = ObjectiveFunction ( x )
%currentX(1) = x(1);
%currentX(2) = x(2);
%currentX(3) = x(3);

%simopt = simset('solver','ode5','SrcWorkspace','Current','DstWorkspace','Current');
%sim('optimisationofPIDPSO.slx',[0 20], simopt)

%open('optimisationofPIDPSO.slx')
 
simout = sim('optimisationofPIDMotorPSO2sobjEasy.slx'); 
v = simout.Mspeed; %% Motor Speed
time = simout.tout %% time
step = simout.step %%step input as a output variable
err = step-v;
%ise = cumtrapz((err.^2), time);
S4 = trapz(err.^2)
S1 = stepinfo(v, time).SettlingTime 
S2 = stepinfo(v, time).RiseTime
S3 = stepinfo(v, time).Overshoot


% a = [S1 S2 S3 S4]
% X = categorical({'SettlingTime(s)','RiseTime(s)','Overshoot(%)', 'Error'});
% X = reordercats(X,{'SettlingTime(s)','RiseTime(s)','Overshoot(%)', 'Error'});
% bar(X, a)
% title('System characteristics with optimised PID values')
% legend
% drawnow



o = S4 %%Cost function 


%Plot all parameters on parrellel axis graph 
end